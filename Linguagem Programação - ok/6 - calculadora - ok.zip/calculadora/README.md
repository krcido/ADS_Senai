# Calculadora de Folha de Pagamento
Esse projeto se constitui em uma calculadora que recebe o valor do salário, o número de dependentes e a opção de Vale de Transporte. Assim que os valores são submetidos, o resultado aparece demonstrando o salário bruto, inss, irrf, vale transporte, o total de desconto e, por fim, o salário líquido. Caso o botão recalcular seja acionado, o usuário pode obter a folha de pagamento de outro salário ou com outros parâmetros.

# Tecnologias utilizadas
- `Html`
- `CSS`
- `JS`
- `VSCODE`

